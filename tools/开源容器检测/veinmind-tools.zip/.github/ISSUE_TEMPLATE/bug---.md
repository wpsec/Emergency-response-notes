---
name: Bug 报告
about: Bug 报告
title: ''
labels: bug
assignees: d1nfinite

---

**Bug 具体描述**

**复现步骤**
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**相关截图**

**环境(空项可以不填)**
 - Docker 版本: 
 - libveinmind 版本:
 - 问脉镜像版本:
 - 代码版本: 

**补充说明**
