# veinmind-example

快速的初始化一个veinmind插件

`make plugin `

参数：

+ NAME: 必填, 插件名称
+ LANG: 插件语言类型, 可选: go/python, 默认go
+ PUB: 是否加入到runner, yes/no, 默认no

示例:

![demo](../docs/veinmind-example/init_plugin.png)