# veinmind-example

for fast auto init a veinmind example plugin

`make plugin `

params:

+ Name: Must, your plugin name
+ Language: plugin use language type, select go/python, default go
+ Pub: do you want to add your plugin to runner? yer/no, default no

example:

![demo](../docs/veinmind-example/exampledemo.png)