package embed

import "embed"

//go:embed rules.toml
var FS embed.FS
