package av

type ScanResult struct {
	EngineName  string
	IsMalicious bool
	Description string
	Method      string
}
