package detect

const token = "API_TOKEN"
const url = "https://guanshan.rivers.chaitin.cn/api/v1/detect"
